package httpscanner;

/**
 *
 * @author chan fook sheng
 * 
 *
 */
public class httpsScanner {

    public static void main(String[] args) throws Exception {
        if (args.length != 4) {
            System.err.println("\n\nUsage: java httpsScanner host port http_method url ");
            System.err.println("Example: java httpsScanner 127.0.0.1 443 HEAD /");
            System.out.println("\nhttpsScanner Version 1.0\n");
            System.out.println("Get the lastest copy of httpsScanner from http://libre-tools.googlecode.com\n");
            System.out.println("Author: Chan Fook Sheng\n");
            System.out.println("This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License Version 3 as published by the Free Software Foundation.\n");
            System.out.println("This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n");
            System.out.println("You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.");
            System.exit(1);
        }

        String host = args[0];
        int port = new Integer(args[1]).intValue();
        String http_method = args[2];
        String url = args[3];

        String ciphersuite[] = {
            "TLS_RSA_WITH_AES_128_CBC_SHA",
            "TLS_DHE_RSA_WITH_AES_128_CBC_SHA",
            "TLS_DHE_DSS_WITH_AES_128_CBC_SHA",
            "TLS_DH_anon_WITH_AES_128_CBC_SHA",
            "SSL_RSA_WITH_3DES_EDE_CBC_SHA",
            "SSL_DHE_RSA_WITH_3DES_EDE_CBC_SHA",
            "SSL_DHE_DSS_WITH_3DES_EDE_CBC_SHA",
            "SSL_DH_anon_WITH_3DES_EDE_CBC_SHA",
            "TLS_KRB5_WITH_3DES_EDE_CBC_SHA",
            "TLS_KRB5_WITH_3DES_EDE_CBC_MD5",
            "SSL_RSA_WITH_NULL_MD5",
            "SSL_RSA_WITH_NULL_SHA",
            "TLS_KRB5_WITH_RC4_128_SHA",
            "TLS_KRB5_WITH_RC4_128_MD5",
            "SSL_RSA_EXPORT_WITH_RC4_40_MD5",
            "SSL_RSA_EXPORT_WITH_DES40_CBC_SHA",
            "SSL_DH_anon_EXPORT_WITH_RC4_40_MD5",
            "SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA",
            "SSL_RSA_WITH_RC4_128_SHA",
            "SSL_RSA_WITH_RC4_128_MD5"
        };


        httpsScannerEngine s = new httpsScannerEngine();
        System.out.println("Scanning " + host + ":" + port);
        System.out.println("HTTP method: " + http_method);
        System.out.println("URL: " + url);

        //s.showCipherSuite(host, port);

        for (int x = 0; x < ciphersuite.length; x++) {
            System.out.println("\n\n" + (x + 1) + ". Using " + ciphersuite[x]);
            boolean connect = s.scan(host, port, http_method, url, ciphersuite[x]);
            if (connect) {
                System.out.println("Connection successful.");
            } else {
                System.out.println("Connection failed.");
            }
        }
        System.out.println("\nhttpsScanner Version 1.0\n");
            System.out.println("Get the lastest copy of httpsScanner from http://libre-tools.googlecode.com\n");
            System.out.println("Author: Chan Fook Sheng\n");
            System.out.println("This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License Version 3 as published by the Free Software Foundation.\n");
            System.out.println("This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n");
            System.out.println("You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.");
    }
}

