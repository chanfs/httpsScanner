package httpscanner;


import java.io.*;
import javax.net.ssl.*;

public class httpsScannerEngine {

    void showCipherSuite(String host, int port) throws Exception {
        SSLSocketFactory factory = (SSLSocketFactory) SSLSocketFactory.getDefault();
        SSLSocket socket = (SSLSocket) factory.createSocket(host, port);
        socket.startHandshake();
        System.out.println("\nEnabled cipher suites: ");
        for (int x = 0; x < socket.getEnabledCipherSuites().length; x++) {
            System.out.println((socket.getEnabledCipherSuites())[x]); //socket.getEnabledCipherSuites() returns a String array String[], so (socket.getEnabledCipherSuites())[x] is = String[x]
        }
        System.out.println("");
    }
    
    boolean scan(String host, int port, String http_method, String url, String ciphersuite) throws Exception {
        SSLSocketFactory factory = (SSLSocketFactory) SSLSocketFactory.getDefault();
        SSLSocket socket = (SSLSocket) factory.createSocket(host, port);
        String str1[] = new String[1];
        str1[0] = ciphersuite;

        socket.setEnabledCipherSuites(str1);
        socket.setUseClientMode(true);
        try {

            socket.startHandshake();

            SSLSession session = socket.getSession();
            System.out.println("Cipher suite in use in this connection: " + session.getCipherSuite());
            System.out.println("Protocol in use in this connection: " + session.getProtocol() + "\n");
            if (socket.getUseClientMode()) {
                System.out.println("Socket is in client mode");
            }
            PrintWriter out = new PrintWriter(
                    new BufferedWriter(
                    new OutputStreamWriter(
                    socket.getOutputStream())));
            out.println(http_method + " " + url + " HTTP/1.1");
            out.println("Host: " + host);
            out.println();
            out.flush();

            
            //Make sure there were no surprises
            if (out.checkError()) {
                System.out.println("SSLSocketClient:  java.io.PrintWriter error");
            }

            //response
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            String inputLine;
            System.out.println("Http response:");
            while ((inputLine = in.readLine()) != null) {
                System.out.println(inputLine);
            }

            in.close();
            out.close();
            socket.close();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }//scan()

    
}

